module.exports = {


  transpileDependencies: [
    'vuetify'
  ]
}
